﻿import re
from pathlib import Path
from datetime import datetime

FILES = {
  "pos": Path("app/models/position.py"),
  "hist": Path("app/models/position_history.py"),
  "svc": Path("app/services/position_service.py"),
  "schema": Path("app/schemas/position.py"),
  "router": Path("app/web/vq_page.py"),
}

for k,p in FILES.items():
    if not p.exists():
        raise SystemExit(f"Brak pliku: {p}")

def backup(p: Path):
    b = p.with_suffix(p.suffix + ".bak_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    b.write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
    print("Backup:", b)
    return b

# ---------------- position model ----------------
backup(FILES["pos"])
pos_src = FILES["pos"].read_text(encoding="utf-8")

# dodaj import Column jeli nie ma (zakadam standardowy pattern)
# wstaw pola jeli nie istniej
if "status =" not in pos_src:
    # spróbuj wstawi przed __table_args__ lub na kocu klasy
    pos_src = re.sub(
        r"(class\s+Position\(Base\):.*?\n)([\s\S]*?)(\n\s*__table_args__|\n\s*def|\n\s*@|\Z)",
        lambda m: m.group(1) + m.group(2) + "\n    status = Column(String)\n    priority = Column(String)\n    owner = Column(String)\n    due_date = Column(String)\n" + (m.group(3) if m.group(3) else ""),
        pos_src,
        count=1
    )
    print("Dodano pola w Position: status/priority/owner/due_date")
else:
    print("Position: pola ju wygldaj na dodane")

# upewnij si e importuje String
if "from sqlalchemy import" in pos_src and "String" not in pos_src.split("from sqlalchemy import",1)[1].split("\n",1)[0]:
    pos_src = re.sub(r"from sqlalchemy import ([^\n]+)", lambda m: "from sqlalchemy import " + m.group(1).strip() + ", String", pos_src, count=1)

FILES["pos"].write_text(pos_src, encoding="utf-8")

# ---------------- position_history model ----------------
backup(FILES["hist"])
h_src = FILES["hist"].read_text(encoding="utf-8")

if "old_status" not in h_src:
    h_src = re.sub(
        r"(class\s+PositionHistory\(Base\):.*?\n)([\s\S]*?)(\n\s*__table_args__|\n\s*def|\n\s*@|\Z)",
        lambda m: m.group(1) + m.group(2) +
        "\n    old_status = Column(String)\n    new_status = Column(String)\n"
        "    old_priority = Column(String)\n    new_priority = Column(String)\n"
        "    old_owner = Column(String)\n    new_owner = Column(String)\n"
        "    old_due_date = Column(String)\n    new_due_date = Column(String)\n"
        + (m.group(3) if m.group(3) else ""),
        h_src,
        count=1
    )
    print("Dodano pola w PositionHistory: old/new status/priority/owner/due_date")
else:
    print("PositionHistory: pola ju wygldaj na dodane")

if "from sqlalchemy import" in h_src and "String" not in h_src.split("from sqlalchemy import",1)[1].split("\n",1)[0]:
    h_src = re.sub(r"from sqlalchemy import ([^\n]+)", lambda m: "from sqlalchemy import " + m.group(1).strip() + ", String", h_src, count=1)

FILES["hist"].write_text(h_src, encoding="utf-8")

# ---------------- schema PositionUpsert ----------------
backup(FILES["schema"])
s_src = FILES["schema"].read_text(encoding="utf-8")

# dodaj pola do PositionUpsert jeli istnieje
if "class PositionUpsert" in s_src and "status:" not in s_src:
    s_src = re.sub(
        r"(class\s+PositionUpsert\(BaseModel\):\n)",
        r"\1"
        r"    topic_id: int\n"
        r"    department_id: int\n"
        r"    content: str | None = None\n"
        r"    client_version: int\n"
        r"    status: str | None = None\n"
        r"    priority: str | None = None\n"
        r"    owner: str | None = None\n"
        r"    due_date: str | None = None\n",
        s_src,
        count=1
    )
    print("Schema: dodano pola do PositionUpsert")
FILES["schema"].write_text(s_src, encoding="utf-8")

# ---------------- service PositionService ----------------
backup(FILES["svc"])
svc_src = FILES["svc"].read_text(encoding="utf-8")

# W tym patchu robimy minimalnie: jeli upsert ma star sygnatur, dopisujemy parametry i zapis + histori.
# Zakadamy, e upsert robi:
# - pobiera/zakada Position
# - conflict by version
# - zapis content
# - dopisuje PositionHistory(old/new)
#
# Podmienimy fragmenty "old_content/new_content" o meta fields.
if "def upsert" not in svc_src:
    raise SystemExit("Nie znalazem def upsert w PositionService - podelij plik app/services/position_service.py")

# dodaj parametry jeli brak
svc_src = re.sub(
    r"def upsert\(([^)]*)\):",
    lambda m: (
        m.group(0)
        if "status" in m.group(1)
        else "def upsert(" + m.group(1).rstrip().rstrip(",") +
             ", status=None, priority=None, owner=None, due_date=None):"
    ),
    svc_src,
    count=1
)

# po ustawieniu content dodaj ustawienie meta pól (bez optymalizacji — wprost)
if "p.status" not in svc_src:
    # spróbuj znale miejsce gdzie jest `p.content = ...`
    svc_src = re.sub(
        r"(p\.content\s*=\s*new_content\s*\n)",
        r"\1"
        r"        p.status = status\n"
        r"        p.priority = priority\n"
        r"        p.owner = owner\n"
        r"        p.due_date = due_date\n",
        svc_src,
        count=1
    )

# dopisz do historii meta pola jeli nie ma
if "old_status" not in svc_src:
    svc_src = re.sub(
        r"PositionHistory\(\s*([\s\S]*?)\)",
        lambda m: m.group(0) if "old_status" in m.group(0) else re.sub(
            r"\)\s*$",
            r",\n            old_status=old_status,\n            new_status=status,\n            old_priority=old_priority,\n            new_priority=priority,\n            old_owner=old_owner,\n            new_owner=owner,\n            old_due_date=old_due_date,\n            new_due_date=due_date,\n        )",
            m.group(0)
        ),
        svc_src,
        count=1
    )

# zapewnij, e przed tworzeniem PositionHistory mamy old_* pobrane
# znajd miejsce gdzie jest old_content = p.content i dopisz old meta
if "old_status =" not in svc_src:
    svc_src = re.sub(
        r"(old_content\s*=\s*p\.content\s*\n)(\s*old_version\s*=\s*p\.version\s*\n)",
        r"\1"
        r"        old_status = getattr(p, 'status', None)\n"
        r"        old_priority = getattr(p, 'priority', None)\n"
        r"        old_owner = getattr(p, 'owner', None)\n"
        r"        old_due_date = getattr(p, 'due_date', None)\n"
        r"\2",
        svc_src,
        count=1
    )

FILES["svc"].write_text(svc_src, encoding="utf-8")
print("OK: PositionService patched (sygnatura + meta + historia)")

# ---------------- router vq_page.py ----------------
backup(FILES["router"])
r_src = FILES["router"].read_text(encoding="utf-8")

# 1) import UploadFile, File
if "UploadFile" not in r_src:
    r_src = r_src.replace("from fastapi import APIRouter, Request, Depends, Form",
                          "from fastapi import APIRouter, Request, Depends, Form, UploadFile, File")

# 2) by_cell: doó status/prio/owner/due_date + attachments_count
if "attachments_count" not in r_src:
    r_src = re.sub(
        r'return\s*\{\s*("id":[\s\S]*?\})',
        lambda m: m.group(0) if "status" in m.group(0) else m.group(0),
        r_src,
        count=0
    )

# patchujemy konkretnie funkcj web_get_by_cell: dopisujemy pola do returna
def patch_return_block(src: str) -> str:
    pat = re.compile(r"@router\.get\(\"/web/positions/by_cell/\{topic_id\}/\{department_id\}\"\)[\s\S]*?return\s*\{([\s\S]*?)\}\s*", re.MULTILINE)
    m = pat.search(src)
    if not m:
        print("WARN: nie znalazem web_get_by_cell return block do patcha (pomijam)")
        return src
    block = m.group(0)
    if '"status"' in block:
        return src
    # dopisz fields tu przed zamykajc }
    block2 = re.sub(
        r'("content":\s*p\.content,\s*\n\s*"version":\s*p\.version,)',
        r'\1\n'
        r'        "status": getattr(p, "status", None),\n'
        r'        "priority": getattr(p, "priority", None),\n'
        r'        "owner": getattr(p, "owner", None),\n'
        r'        "due_date": getattr(p, "due_date", None),',
        block,
        count=1
    )
    # attachments_count – liczymy prostym query po tabeli position_attachments (SQL raw)
    if "attachments_count" not in block2:
        block2 = block2.replace(
            '"last_changed_by": last.changed_by if last else None,',
            '"last_changed_by": last.changed_by if last else None,\n'
            '        "attachments_count": db.execute("SELECT COUNT(1) FROM position_attachments WHERE position_id = :pid", {"pid": p.id}).scalar() or 0,'
        )
    return src[:m.start()] + block2 + src[m.end():]

r_src = patch_return_block(r_src)

# 3) upsert endpoint: dodaj Form pola i przeka do svc.upsert
if "status: str = Form" not in r_src:
    r_src = re.sub(
        r"def web_upsert\(\s*request: Request,\s*topic_id: int = Form\(\.\.\.\),\s*department_id: int = Form\(\.\.\.\),\s*content: str = Form\(\"\"\),\s*client_version: int = Form\(\.\.\.\),",
        "def web_upsert(\n"
        "    request: Request,\n"
        "    topic_id: int = Form(...),\n"
        "    department_id: int = Form(...),\n"
        "    content: str = Form(\"\"),\n"
        "    client_version: int = Form(...),\n"
        "    status: str | None = Form(None),\n"
        "    priority: str | None = Form(None),\n"
        "    owner: str | None = Form(None),\n"
        "    due_date: str | None = Form(None),\n",
        r_src,
        count=1
    )

# przeka parametry do svc.upsert(...)
r_src = re.sub(
    r"svc\.upsert\(\s*db,\s*topic_id,\s*department_id,\s*content if content != \"\" else None,\s*user_id,\s*client_version\s*\)",
    "svc.upsert(db, topic_id, department_id, content if content != \"\" else None, user_id, client_version, status=status, priority=priority, owner=owner, due_date=due_date)",
    r_src,
    count=1
)

# 4) upsert return: dopisz status/prio/owner/due_date + attachments_count
if '"status": getattr(p, "status", None)' not in r_src:
    r_src = re.sub(
        r'"content": p\.content,\s*\n\s*"version": p\.version,',
        '"content": p.content,\n            "version": p.version,\n            "status": getattr(p, "status", None),\n            "priority": getattr(p, "priority", None),\n            "owner": getattr(p, "owner", None),\n            "due_date": getattr(p, "due_date", None),',
        r_src,
        count=1
    )
if '"attachments_count"' not in r_src:
    r_src = r_src.replace(
        '"last_changed_by": last.changed_by if last else None,',
        '"last_changed_by": last.changed_by if last else None,\n            "attachments_count": db.execute("SELECT COUNT(1) FROM position_attachments WHERE position_id = :pid", {"pid": p.id}).scalar() or 0,'
    )

# 5) restore endpoint jeli nie ma
if '"/web/positions/restore"' not in r_src:
    r_src += """

@router.post("/web/positions/restore")
def web_restore(
    request: Request,
    topic_id: int = Form(...),
    department_id: int = Form(...),
    history_id: int = Form(...),
    client_version: int = Form(...),
    db: Session = Depends(get_db),
):
    user_id = current_user_id_from_cookie(request, db)
    if user_id is None:
        return JSONResponse({"detail": "unauthorized"}, status_code=401)

    p = db.query(Position).filter(
        Position.topic_id == topic_id,
        Position.department_id == department_id
    ).first()
    if not p:
        return JSONResponse({"detail": "not_found"}, status_code=404)

    if int(client_version) != int(p.version):
        return JSONResponse({"detail": "conflict"}, status_code=409)

    h = db.query(PositionHistory).filter(PositionHistory.id == history_id).first()
    if not h or h.position_id != p.id:
        return JSONResponse({"detail": "bad_history"}, status_code=400)

    old_content = p.content
    old_version = p.version
    old_status = getattr(p, "status", None)
    old_priority = getattr(p, "priority", None)
    old_owner = getattr(p, "owner", None)
    old_due_date = getattr(p, "due_date", None)

    new_content = h.new_content
    new_status = getattr(h, "new_status", None)
    new_priority = getattr(h, "new_priority", None)
    new_owner = getattr(h, "new_owner", None)
    new_due_date = getattr(h, "new_due_date", None)

    p.content = new_content
    p.status = new_status
    p.priority = new_priority
    p.owner = new_owner
    p.due_date = new_due_date
    p.version = int(p.version) + 1

    db.add(PositionHistory(
        position_id=p.id,
        old_content=old_content,
        new_content=new_content,
        old_version=old_version,
        new_version=p.version,
        changed_by=user_id,
        old_status=old_status,
        new_status=new_status,
        old_priority=old_priority,
        new_priority=new_priority,
        old_owner=old_owner,
        new_owner=new_owner,
        old_due_date=old_due_date,
        new_due_date=new_due_date,
    ))

    db.commit()
    db.refresh(p)

    last = get_last_history_row(db, p.id)

    return {
        "id": p.id,
        "topic_id": p.topic_id,
        "department_id": p.department_id,
        "content": p.content,
        "version": p.version,
        "status": getattr(p, "status", None),
        "priority": getattr(p, "priority", None),
        "owner": getattr(p, "owner", None),
        "due_date": getattr(p, "due_date", None),
        "last_changed_at": last.changed_at.isoformat() if last and last.changed_at else None,
        "last_changed_by": last.changed_by if last else None,
        "attachments_count": db.execute("SELECT COUNT(1) FROM position_attachments WHERE position_id = :pid", {"pid": p.id}).scalar() or 0,
    }
"""

# 6) upload/list zdj endpoints
if '"/web/positions/attachments/upload"' not in r_src:
    r_src += """

@router.post("/web/positions/attachments/upload")
def web_upload_attachment(
    request: Request,
    topic_id: int = Form(...),
    department_id: int = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    user_id = current_user_id_from_cookie(request, db)
    if user_id is None:
        return JSONResponse({"detail": "unauthorized"}, status_code=401)

    p = db.query(Position).filter(Position.topic_id == topic_id, Position.department_id == department_id).first()
    if not p:
        return JSONResponse({"detail": "not_found"}, status_code=404)

    import os, uuid
    from datetime import datetime as _dt

    up_dir = Path("uploads/positions")
    up_dir.mkdir(parents=True, exist_ok=True)

    ext = ""
    if file.filename and "." in file.filename:
        ext = "." + file.filename.split(".")[-1].lower()

    fname = str(uuid.uuid4()) + ext
    fpath = up_dir / fname

    data = file.file.read()
    fpath.write_bytes(data)

    db.execute(
        "INSERT INTO position_attachments(position_id, file_path, original_name, mime_type, uploaded_by, uploaded_at) "
        "VALUES (:pid, :fp, :on, :mt, :ub, :ua)",
        {
            "pid": p.id,
            "fp": str(fpath).replace("\\\\", "/"),
            "on": file.filename,
            "mt": file.content_type,
            "ub": user_id,
            "ua": _dt.utcnow().isoformat(),
        }
    )
    db.commit()

    cnt = db.execute("SELECT COUNT(1) FROM position_attachments WHERE position_id = :pid", {"pid": p.id}).scalar() or 0

    return {"ok": True, "attachments_count": cnt}


@router.get("/web/positions/attachments/by_cell/{topic_id}/{department_id}")
def web_list_attachments(topic_id: int, department_id: int, request: Request, db: Session = Depends(get_db)):
    if not request.cookies.get("access_token"):
        return JSONResponse({"detail": "unauthorized"}, status_code=401)

    p = db.query(Position).filter(Position.topic_id == topic_id, Position.department_id == department_id).first()
    if not p:
        return []

    rows = db.execute(
        "SELECT id, file_path, original_name, mime_type, uploaded_by, uploaded_at "
        "FROM position_attachments WHERE position_id = :pid ORDER BY id DESC LIMIT 30",
        {"pid": p.id}
    ).fetchall()

    return [
        {
            "id": r[0],
            "file_path": r[1],
            "original_name": r[2],
            "mime_type": r[3],
            "uploaded_by": r[4],
            "uploaded_at": r[5],
            "url": "/web/positions/attachments/" + str(r[0]),
        }
        for r in rows
    ]


@router.get("/web/positions/attachments/{attachment_id}")
def web_get_attachment(attachment_id: int, request: Request, db: Session = Depends(get_db)):
    if not request.cookies.get("access_token"):
        return JSONResponse({"detail": "unauthorized"}, status_code=401)

    row = db.execute(
        "SELECT file_path, mime_type, original_name FROM position_attachments WHERE id = :id",
        {"id": attachment_id}
    ).fetchone()
    if not row:
        return JSONResponse({"detail": "not_found"}, status_code=404)

    from fastapi.responses import FileResponse
    fp, mt, on = row[0], row[1], row[2]
    if not Path(fp).exists():
        return JSONResponse({"detail": "file_missing"}, status_code=404)

    return FileResponse(fp, media_type=mt or "application/octet-stream", filename=on or Path(fp).name)
"""

FILES["router"].write_text(r_src, encoding="utf-8")
print("DONE backend patch")
