﻿import re
from pathlib import Path
from datetime import datetime

path = Path("app/web/templates/vq_matrix.html")
if not path.exists():
    raise SystemExit(f"Nie znaleziono: {path}")

src = path.read_text(encoding="utf-8")
bak = path.with_suffix(path.suffix + ".bak_tipfix_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
bak.write_text(src, encoding="utf-8")
print("Backup:", bak)

out = src

# 1) CSS: tooltip nie moe przechwytywa myszy (bo blokuje klik i mouseleave)
#    + drobna poprawa: jeli tooltip jest widoczny, niech nie zabiera focusu
tip_block_pat = re.compile(r"\.tip\s*\{([\s\S]*?)\}", re.MULTILINE)
m = tip_block_pat.search(out)
if not m:
    raise SystemExit("Nie znalazem bloku CSS .tip { ... }")

tip_body = m.group(1)
if "pointer-events" not in tip_body:
    # dopisz na kocu body tooltipa
    tip_body2 = tip_body.rstrip() + "\n    pointer-events: none;\n"
    out = out[:m.start(1)] + tip_body2 + out[m.end(1):]
    print("OK: dodano pointer-events:none do .tip")
else:
    print("OK: .tip ma ju pointer-events")

# 2) JS: xhr – dodaj timeout + obsug error, eby "adowanie..." nie wisiao w nieskoczono
#    Szukamy funkcji xhr(...) i dopisujemy timeout / onerror / ontimeout
xhr_pat = re.compile(r"function\s+xhr\s*\(\s*method\s*,\s*url\s*,\s*body\s*,\s*contentType\s*,\s*cb\s*\)\s*\{\s*([\s\S]*?)\n\s*\}", re.MULTILINE)
mx = xhr_pat.search(out)
if not mx:
    raise SystemExit("Nie znalazem funkcji xhr(method, url, body, contentType, cb)")

xhr_block = mx.group(0)
if "r.timeout" not in xhr_block:
    # wstaw tu po r.open(...)
    xhr_block2 = re.sub(
        r"(r\.open\(\s*method\s*,\s*url\s*,\s*true\s*\);\s*)",
        r"\1\n    r.timeout = 8000;\n",
        xhr_block,
        count=1
    )
    # dodaj onerror/ontimeout przed r.send(body)
    if "r.onerror" not in xhr_block2:
        xhr_block2 = xhr_block2.replace(
            "    r.send(body);",
            "    r.onerror = function(){ cb(0, 'network_error'); };\n"
            "    r.ontimeout = function(){ cb(0, 'timeout'); };\n"
            "    r.send(body);"
        )
    out = out[:mx.start()] + xhr_block2 + out[mx.end():]
    print("OK: dodano timeout/onerror/ontimeout do xhr()")
else:
    print("OK: xhr() ma ju timeout")

# 3) JS: przy klikniciu w komórk chowamy wszystkie tipy (eby nie zostaway na wierzchu)
#    W bindCells() jest: cell.onclick = function(){ openModal(cell); };
#    Podmieniamy na: hideAllTips(); openModal(cell);
if "function hideAllTips" in out:
    out2 = out.replace(
        "cell.onclick = function(){ openModal(cell); };",
        "cell.onclick = function(){ hideAllTips(); openModal(cell); };"
    )
    if out2 != out:
        out = out2
        print("OK: bindCells() chowa tipy przed openModal()")
    else:
        print("WARN: nie znalazem dokadnej linii onclick w bindCells() (pomijam)")
else:
    print("WARN: brak hideAllTips() w pliku (pomijam krok 3)")

path.write_text(out, encoding="utf-8")
print("DONE:", path)
