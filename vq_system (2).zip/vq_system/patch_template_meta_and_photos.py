﻿import re
from pathlib import Path
from datetime import datetime

path = Path("app/web/templates/vq_matrix.html")
if not path.exists():
    raise SystemExit(f"Nie znaleziono template: {path}")

src = path.read_text(encoding="utf-8")
bak = path.with_suffix(path.suffix + ".bak_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
bak.write_text(src, encoding="utf-8")
print("Backup:", bak)

out = src

# 1) CSS: kolory statusów + badge + upload
if ".statusBadge" not in out:
    out = out.replace(
        "<style>",
        "<style>\n"
        "  .statusBadge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;margin-right:6px;}\n"
        "  .badgeSmall{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;background:#eee;margin-right:6px;}\n"
        "  .cellbadges{margin-bottom:6px;}\n"
        "  td.cell.status_OK{background:rgba(0,160,0,0.10);} \n"
        "  td.cell.status_RYZYKO{background:rgba(255,140,0,0.12);} \n"
        "  td.cell.status_BLOKADA{background:rgba(220,0,0,0.12);} \n"
        "  td.cell.status_DECYZJA{background:rgba(0,90,255,0.10);} \n"
        "  .status_OK .statusBadge{background:rgba(0,160,0,0.20);} \n"
        "  .status_RYZYKO .statusBadge{background:rgba(255,140,0,0.25);} \n"
        "  .status_BLOKADA .statusBadge{background:rgba(220,0,0,0.25);} \n"
        "  .status_DECYZJA .statusBadge{background:rgba(0,90,255,0.22);} \n"
        "  .photoMark{font-size:12px;margin-left:6px;opacity:0.85;}\n"
        "  .modalRow{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0;}\n"
        "  .modalRow label{font-size:12px;color:#555;display:block;margin-bottom:4px;}\n"
        "  .modalRow .f{min-width:160px;}\n"
        "  .modalRow select,.modalRow input{padding:8px;border-radius:8px;border:1px solid #ccc;}\n"
        "  .attList a{display:block;margin:4px 0;font-size:12px;}\n"
    )
    print("Dodano CSS: badge/kolory/status/photos/modal fields")

# 2) HTML w komórce: wstaw badge placeholder nad content
if "class=\"cellbadges\"" not in out:
    out = re.sub(
        r"(<div class=\"cellmeta\">[\s\S]*?</div>\s*)",
        r"\1<div class=\"cellbadges\"></div>\n",
        out,
        count=1
    )
    print("Dodano <div class='cellbadges'> w komórce")

# 3) data-attr w td: status/priority/owner/due_date/attachments_count
def add_data_attr(match):
    td = match.group(0)
    if "data-status" in td:
        return td
    insert = (
        "            data-status=\"{{ (p.status if p else '')|e }}\"\n"
        "            data-priority=\"{{ (p.priority if p else '')|e }}\"\n"
        "            data-owner=\"{{ (p.owner if p else '')|e }}\"\n"
        "            data-due-date=\"{{ (p.due_date if p else '')|e }}\"\n"
        "            data-attachments-count=\"{{ (p.attachments_count if p else 0) }}\"\n"
    )
    return td.replace("data-version", insert + "            data-version")

out = re.sub(r"<td class=\"cell\"[\s\S]*?data-version=", add_data_attr, out, count=1)
print("OK: data-attr (status/priority/owner/due_date/attachments_count)")

# 4) Modal: dodaj pola status/priority/owner/due_date + upload
if "id=\"modalStatus\"" not in out:
    out = out.replace(
        "<textarea id=\"modalText\" style=\"width:100%; min-height:200px;\"></textarea>",
        "<div class=\"modalRow\">\n"
        "  <div class=\"f\"><label>Status</label>\n"
        "    <select id=\"modalStatus\">\n"
        "      <option value=\"\">—</option>\n"
        "      <option value=\"OK\">OK</option>\n"
        "      <option value=\"RYZYKO\">RYZYKO</option>\n"
        "      <option value=\"BLOKADA\">BLOKADA</option>\n"
        "      <option value=\"DECYZJA\">DECYZJA</option>\n"
        "    </select>\n"
        "  </div>\n"
        "  <div class=\"f\"><label>Priorytet</label>\n"
        "    <select id=\"modalPriority\">\n"
        "      <option value=\"\">—</option>\n"
        "      <option value=\"P1\">P1</option>\n"
        "      <option value=\"P2\">P2</option>\n"
        "      <option value=\"P3\">P3</option>\n"
        "    </select>\n"
        "  </div>\n"
        "  <div class=\"f\"><label>Owner</label><input id=\"modalOwner\" type=\"text\" placeholder=\"np. Janek\" /></div>\n"
        "  <div class=\"f\"><label>Termin</label><input id=\"modalDue\" type=\"date\" /></div>\n"
        "</div>\n"
        "<textarea id=\"modalText\" style=\"width:100%; min-height:200px;\"></textarea>\n"
        "<div class=\"modalRow\">\n"
        "  <div class=\"f\" style=\"min-width:320px;\">\n"
        "    <label>Dodaj zdjcie</label>\n"
        "    <input id=\"modalPhoto\" type=\"file\" accept=\"image/*\" />\n"
        "    <div id=\"modalAtt\" class=\"attList\"></div>\n"
        "  </div>\n"
        "</div>"
    )
    print("Dodano pola w modalu + upload")

# 5) JS: dodaj referencje do nowych pól + funkcje badge/kolor + upload/list
if "function applyCellDecor" not in out:
    # znajd miejsce po var modalText = ...
    out = out.replace(
        "  var modalText = document.getElementById(\"modalText\");",
        "  var modalText = document.getElementById(\"modalText\");\n"
        "  var modalStatus = document.getElementById(\"modalStatus\");\n"
        "  var modalPriority = document.getElementById(\"modalPriority\");\n"
        "  var modalOwner = document.getElementById(\"modalOwner\");\n"
        "  var modalDue = document.getElementById(\"modalDue\");\n"
        "  var modalPhoto = document.getElementById(\"modalPhoto\");\n"
        "  var modalAtt = document.getElementById(\"modalAtt\");\n"
    )

    # wstaw helpery przed // -------- EDIT MODAL ----------
    out = out.replace(
        "  // -------- EDIT MODAL ----------",
        "  function getCellStatus(cell){ return (cell.getAttribute('data-status')||'').trim(); }\n"
        "  function applyCellDecor(cell){\n"
        "    var st = (cell.getAttribute('data-status')||'').trim();\n"
        "    cell.classList.remove('status_OK','status_RYZYKO','status_BLOKADA','status_DECYZJA');\n"
        "    if (st) cell.classList.add('status_'+st);\n"
        "    var badges = cell.getElementsByClassName('cellbadges')[0];\n"
        "    if (!badges) return;\n"
        "    var pr = (cell.getAttribute('data-priority')||'').trim();\n"
        "    var ow = (cell.getAttribute('data-owner')||'').trim();\n"
        "    var dd = (cell.getAttribute('data-due-date')||'').trim();\n"
        "    var ac = parseInt(cell.getAttribute('data-attachments-count')||'0',10) || 0;\n"
        "    var html = '';\n"
        "    if (st) html += \"<span class='statusBadge'>\"+escapeHtml(st)+\"</span>\";\n"
        "    if (pr) html += \"<span class='badgeSmall'>\"+escapeHtml(pr)+\"</span>\";\n"
        "    if (ow) html += \"<span class='badgeSmall'>\"+escapeHtml(ow)+\"</span>\";\n"
        "    if (dd) html += \"<span class='badgeSmall'>\"+escapeHtml(dd)+\"</span>\";\n"
        "    if (ac>0) html += \"<span class='photoMark'>📷\"+ac+\"</span>\";\n"
        "    badges.innerHTML = html;\n"
        "  }\n"
        "\n"
        "  function loadAttachmentsToModal(topicId, depId){\n"
        "    if (!modalAtt) return;\n"
        "    modalAtt.innerHTML = '';\n"
        "    xhr('GET', '/web/positions/attachments/by_cell/'+topicId+'/'+depId, null, null, function(status, text){\n"
        "      if (!(status>=200 && status<300)) return;\n"
        "      var items=[]; try{ items = text?JSON.parse(text):[]; }catch(e){ items=[]; }\n"
        "      if (!items.length) { modalAtt.innerHTML = \"<div style='font-size:12px;color:#777;'>Brak zdj</div>\"; return; }\n"
        "      var html='';\n"
        "      for (var i=0;i<items.length;i++){\n"
        "        var it=items[i];\n"
        "        var nm = it.original_name || ('zdjecie_'+it.id);\n"
        "        html += \"<a href='\"+escapeHtml(it.url)+\"' target='_blank'>📷 \"+escapeHtml(nm)+\"</a>\";\n"
        "      }\n"
        "      modalAtt.innerHTML = html;\n"
        "    });\n"
        "  }\n"
        "\n"
        "  function uploadPhoto(topicId, depId, cb){\n"
        "    if (!modalPhoto || !modalPhoto.files || !modalPhoto.files.length) { if(cb) cb(); return; }\n"
        "    var fd = new FormData();\n"
        "    fd.append('topic_id', topicId);\n"
        "    fd.append('department_id', depId);\n"
        "    fd.append('file', modalPhoto.files[0]);\n"
        "    var r = new XMLHttpRequest();\n"
        "    r.open('POST','/web/positions/attachments/upload', true);\n"
        "    r.onreadystatechange = function(){\n"
        "      if (r.readyState!==4) return;\n"
        "      try{\n"
        "        if (r.status>=200 && r.status<300){\n"
        "          var resp = JSON.parse(r.responseText||'{}');\n"
        "          if (currentCell && resp.attachments_count!==undefined) currentCell.setAttribute('data-attachments-count', String(resp.attachments_count));\n"
        "          modalPhoto.value='';\n"
        "        }\n"
        "      }catch(e){}\n"
        "      if(cb) cb();\n"
        "    };\n"
        "    r.send(fd);\n"
        "  }\n"
        "\n"
        "  // -------- EDIT MODAL ----------"
    )
    print("Dodano JS helpery: applyCellDecor + attachments upload/list")

# 6) openModal: ustaw wartoci pól + load attachments
if "loadAttachmentsToModal" in out and "loadAttachmentsToModal(topicId, depId);" not in out:
    out = out.replace(
        "        modalText.value = cell.getAttribute(\"data-content\") || \"\";",
        "        modalText.value = cell.getAttribute(\"data-content\") || \"\";\n"
        "        if (modalStatus) modalStatus.value = p && p.status ? p.status : '';\n"
        "        if (modalPriority) modalPriority.value = p && p.priority ? p.priority : '';\n"
        "        if (modalOwner) modalOwner.value = p && p.owner ? p.owner : '';\n"
        "        if (modalDue) modalDue.value = p && p.due_date ? p.due_date : '';\n"
        "        loadAttachmentsToModal(topicId, depId);\n"
    )

# 7) btnSave: dopisz pola do body + po sukcesie set data-attr + applyCellDecor + uploadPhoto
if "&status=" not in out:
    out = out.replace(
        "+ \"&client_version=\" + encodeURIComponent(clientVersion);",
        "+ \"&client_version=\" + encodeURIComponent(clientVersion)\n"
        "      + \"&status=\" + encodeURIComponent((modalStatus && modalStatus.value) ? modalStatus.value : \"\")\n"
        "      + \"&priority=\" + encodeURIComponent((modalPriority && modalPriority.value) ? modalPriority.value : \"\")\n"
        "      + \"&owner=\" + encodeURIComponent((modalOwner && modalOwner.value) ? modalOwner.value : \"\")\n"
        "      + \"&due_date=\" + encodeURIComponent((modalDue && modalDue.value) ? modalDue.value : \"\");"
    )

# po sukcesie zapisu: ustaw data-* i applyCellDecor + uploadPhoto
if "applyCellDecor(currentCell);" not in out:
    out = out.replace(
        "      currentCell.setAttribute(\"data-content\", p.content || \"\");",
        "      currentCell.setAttribute(\"data-content\", p.content || \"\");\n"
        "      currentCell.setAttribute(\"data-status\", p.status || \"\");\n"
        "      currentCell.setAttribute(\"data-priority\", p.priority || \"\");\n"
        "      currentCell.setAttribute(\"data-owner\", p.owner || \"\");\n"
        "      currentCell.setAttribute(\"data-due-date\", p.due_date || \"\");\n"
        "      if (p.attachments_count !== undefined) currentCell.setAttribute(\"data-attachments-count\", String(p.attachments_count));\n"
    )
    out = out.replace(
        "      metaDiv.innerHTML = \"v\" + p.version;",
        "      metaDiv.innerHTML = \"v\" + p.version;\n"
        "      applyCellDecor(currentCell);\n"
        "      uploadPhoto(topicId, departmentId, function(){\n"
        "        applyCellDecor(currentCell);\n"
        "        loadAttachmentsToModal(topicId, departmentId);\n"
        "      });"
    )

# 8) init po starcie: applyCellDecor wszystkim
if "applyCellDecor(cell);" not in out:
    out = out.replace(
        "  bindCells();",
        "  // init decor (kolor + badge) na starcie\n"
        "  (function(){\n"
        "    var cells = document.getElementsByClassName('cell');\n"
        "    for (var i=0;i<cells.length;i++) applyCellDecor(cells[i]);\n"
        "  })();\n"
        "  bindCells();"
    )

path.write_text(out, encoding="utf-8")
print("DONE template patch:", path)
