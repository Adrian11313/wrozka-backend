﻿import re
from pathlib import Path
from datetime import datetime

path = Path("app/services/position_service.py")
if not path.exists():
    raise SystemExit(f"Brak pliku: {path}")

src = path.read_text(encoding="utf-8")

bak = path.with_suffix(path.suffix + ".bak_fix_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
bak.write_text(src, encoding="utf-8")
print("Backup:", bak)

out = src

# 1) usu linie które s tylko przecinkiem (to jest dokadnie Twój SyntaxError)
out2 = re.sub(r"(?m)^\s*,\s*$\n?", "", out)
if out2 != out:
    print("OK: usunito linie z samotnym przecinkiem ','")
out = out2

# 2) popraw typowe rozwalenie sygnatury: przecinek tu przed zamkniciem nawiasu
#    np. ... due_date=None,):
out2 = re.sub(r",\s*\)\s*:", "):", out)
if out2 != out:
    print("OK: poprawiono ',):' -> '):'")
out = out2

# 3) usu podwójne przecinki (czasem patch potrafi zrobi ', ,')
out2 = re.sub(r",\s*,", ",", out)
if out2 != out:
    print("OK: usunito podwójne przecinki ', ,'")
out = out2

# 4) usu przecinek bezporednio przed kocem argumentów w wywoaniu, jeli patch wstawi go bdnie
#    (konserwatywnie: tylko gdy jest przed \n) w kontekcie funkcji/wywoania)
out2 = re.sub(r",\s*\n(\s*\))", r"\n\1", out)
if out2 != out:
    print("OK: usunito przecinek przed ')'")
out = out2

path.write_text(out, encoding="utf-8")
print("DONE:", path)
