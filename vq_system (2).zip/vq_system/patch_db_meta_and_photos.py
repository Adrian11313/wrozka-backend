﻿from pathlib import Path
import sqlite3
from datetime import datetime

DB_PATH = Path("vq.db")  # zgodnie z DATABASE_URL: sqlite:///./vq.db

if not DB_PATH.exists():
    raise SystemExit(f"Nie znaleziono bazy: {DB_PATH.resolve()}")

bak = DB_PATH.with_suffix(".db.bak_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
bak.write_bytes(DB_PATH.read_bytes())
print("Backup DB:", bak)

con = sqlite3.connect(str(DB_PATH))
cur = con.cursor()

def table_cols(table):
    cur.execute(f"PRAGMA table_info({table})")
    return {row[1] for row in cur.fetchall()}

def add_col(table, col, ddl):
    cols = table_cols(table)
    if col in cols:
        print(f"OK: {table}.{col} ju istnieje")
        return
    cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
    print(f"Dodano: {table}.{col} {ddl}")

# --- positions: dodaj pola status/prio/owner/due_date
for col, ddl in [
    ("status", "TEXT"),
    ("priority", "TEXT"),
    ("owner", "TEXT"),
    ("due_date", "TEXT"),
]:
    add_col("positions", col, ddl)

# --- position_history: dodaj stare/nowe meta pola (eby restore przywraca peny stan)
for col, ddl in [
    ("old_status", "TEXT"),
    ("new_status", "TEXT"),
    ("old_priority", "TEXT"),
    ("new_priority", "TEXT"),
    ("old_owner", "TEXT"),
    ("new_owner", "TEXT"),
    ("old_due_date", "TEXT"),
    ("new_due_date", "TEXT"),
]:
    add_col("position_history", col, ddl)

# --- attachments: nowa tabela
cur.execute("""
CREATE TABLE IF NOT EXISTS position_attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  position_id INTEGER NOT NULL,
  file_path TEXT NOT NULL,
  original_name TEXT,
  mime_type TEXT,
  uploaded_by INTEGER,
  uploaded_at TEXT,
  FOREIGN KEY(position_id) REFERENCES positions(id)
)
""")
print("OK: tabela position_attachments (jeli nie byo)")

con.commit()
con.close()

print("DONE")
